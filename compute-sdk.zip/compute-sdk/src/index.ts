// Re-export Result utilities so consumers don't need a direct better-result dependency
export {
  Err,
  matchError,
  matchErrorPartial,
  Ok,
  type Result,
  TaggedError,
} from "better-result";
export type {
  ApplyMigrationsOptions,
  ApplyMigrationsResult,
} from "./apply-migrations.ts";
export { applyMigrations } from "./apply-migrations.ts";
export { createArchive } from "./archive.ts";
export { normalizeArtifactSymlinks } from "./artifact-postprocess.ts";
export {
  hoistIsolatedStoreDependencies,
  stageStandaloneArtifact,
} from "./artifact-stage.ts";
export { AstroBuild } from "./astro-build.ts";
export { AutoBuild } from "./auto-build.ts";
export {
  type BuildStrategyHooks,
  type BuildType,
  createBuildStrategy,
  resolveBuildStrategy,
} from "./build.ts";
export {
  type BuildSettings,
  joinPosix,
  nextOutputRootFromStandaloneDirectory,
  readStaticNextConfig,
  resolveBuildSettings,
  resolveConfiguredBuildSettings,
} from "./build-settings.ts";
export type { BuildArtifact, BuildStrategy } from "./build-strategy.ts";
export { PreBuilt } from "./build-strategy.ts";
export { BunBuild } from "./bun-build.ts";
export type {
  DeployInteraction,
  DeployProgress,
  DestroyAppProgress,
  DestroyDeploymentInteraction,
  DestroyDeploymentProgress,
  PromoteProgress,
  UpdateEnvProgress,
} from "./callbacks.ts";
export type {
  CreateAppOptions,
  CreateProjectOptions,
  DeleteAppOptions,
  DeleteDeploymentOptions,
  DeployOptions,
  DeployResult,
  DestroyAppOptions,
  DestroyAppResult,
  DestroyDeploymentOptions,
  DestroyDeploymentResult,
  ListAppsOptions,
  ListDeploymentsOptions,
  ListProjectsOptions,
  PromoteOptions,
  PromoteResult,
  ShowAppOptions,
  ShowDeploymentOptions,
  StartDeploymentOptions,
  StopDeploymentOptions,
  UpdateEnvOptions,
  UpdateEnvResult,
} from "./compute-client.ts";
export { ComputeClient } from "./compute-client.ts";
export { CustomBuild } from "./custom-build.ts";
export type {
  DetectedSchema,
  MigrationCommand,
  SchemaDetection,
  SchemaEngine,
  UnsupportedSchema,
  UnsupportedSchemaTarget,
} from "./detect-schema.ts";
export { detectAppSchema } from "./detect-schema.ts";
export type {
  ApiRequestError,
  DeployError,
  DeploymentOperationError,
  DestroyAppError,
  DestroyDeploymentError,
  PromoteError,
  UpdateEnvError,
} from "./errors.ts";
export {
  ApiError,
  ArtifactError,
  AuthenticationError,
  BuildError,
  CancelledError,
  DeploymentFailedError,
  DestroyAggregateError,
  InvalidOptionsError,
  LogStreamError,
  MissingArgumentError,
  NoDeploymentsFoundError,
  NoExistingDeploymentError,
  TimeoutError,
} from "./errors.ts";
export type {
  LogRecord,
  LogStreamOptions,
  StreamLogsError,
  StreamRecord,
  StreamResult,
  TerminalRecord,
} from "./log-stream.ts";
export { streamLogs } from "./log-stream.ts";
export { NestjsBuild } from "./nestjs-build.ts";
export { NextjsBuild } from "./nextjs-build.ts";
export { NuxtBuild } from "./nuxt-build.ts";
export { TanstackStartBuild } from "./tanstack-start-build.ts";
export type {
  AppDetail,
  AppInfo,
  ComputeRegion,
  CreateProjectResult,
  DatabaseInfo,
  DeploymentDetail,
  DeploymentInfo,
  PortMapping,
  ProjectInfo,
  RegionInfo,
  ResolvedConfig,
} from "./types.ts";
export { KNOWN_REGION_IDS, REGIONS } from "./types.ts";
export { uploadArtifact } from "./upload-artifact.ts";
export {
  type BuildCommandIo,
  buildCommandEnv,
  type PackageManager,
  type PackageManifest,
  readBuildScript,
  readPackageManifest,
  resolvePackageManager,
  runBuildCommand,
} from "./workspace.ts";
