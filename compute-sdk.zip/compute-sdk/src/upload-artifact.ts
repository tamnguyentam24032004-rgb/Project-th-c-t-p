/**
 * PUT a gzipped compute artifact to a Foundry-minted presigned upload URL.
 */
export async function uploadArtifact(
  uploadUrl: string,
  body: Uint8Array,
  signal?: AbortSignal,
): Promise<void> {
  signal?.throwIfAborted();
  // Intentionally do not pass AbortSignal to this mutating upload request.
  // Aborting transport can leave completion ambiguous server-side.
  const response = await fetch(uploadUrl, {
    method: "PUT",
    headers: { "content-type": "application/gzip" },
    body,
  });

  if (!response.ok) {
    let message = `Artifact upload failed with HTTP ${response.status}`;
    try {
      const json = (await response.json()) as { error?: unknown };
      if (typeof json.error === "string" && json.error.length > 0) {
        message = `Artifact upload failed: ${json.error}`;
      }
    } catch {
      // ignore body parse failures
    }
    throw new Error(message);
  }
}
