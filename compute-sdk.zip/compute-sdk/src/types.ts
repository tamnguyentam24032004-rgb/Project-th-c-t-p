/**
 * Domain types for the Compute SDK.
 */

import { COMPUTE_REGIONS } from "./config/types.ts";

export interface PortMapping {
  http?: number | null;
}

export interface ProjectInfo {
  id: string;
  name: string;
  defaultRegion?: string;
}

export interface DatabaseInfo {
  id: string;
  name: string;
  region: string;
  connectionString?: string;
}

export interface CreateProjectResult extends ProjectInfo {
  database?: DatabaseInfo;
}

export interface AppInfo {
  id: string;
  name: string;
  region: string;
  projectId: string;
  createdAt?: string;
}

export interface AppDetail extends AppInfo {
  latestDeploymentId?: string | null;
  appEndpointDomain?: string;
}

export interface DeploymentInfo {
  id: string;
  status: string;
  createdAt: string;
  previewDomain?: string | null;
}

export interface DeploymentDetail extends DeploymentInfo {
  serviceId: string;
  envVars?: Record<string, string | null>;
  foundryVersionId?: string;
}

export interface RegionInfo {
  id: string;
  displayName: string;
}

export interface ResolvedConfig {
  projectId: string;
  appId: string;
  appName: string;
  region: string;
  portMapping?: PortMapping;
}

export type { ComputeRegion } from "./config/types.ts";

/** Known compute region identifiers, used by the CLI for interactive prompts. */
export const KNOWN_REGION_IDS = COMPUTE_REGIONS;
export const REGIONS: RegionInfo[] = KNOWN_REGION_IDS.map((id) => ({
  id,
  displayName: id,
}));
