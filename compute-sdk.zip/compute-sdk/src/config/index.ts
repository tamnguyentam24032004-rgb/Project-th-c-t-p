/**
 * The compute config contract and its tooling: types, validation, discovery,
 * loading, and serialization for `prisma.compute.ts`.
 *
 * Consumers (CLI, build-runner, scaffolding) share this module so every part
 * of the platform reads the same deploy graph. Consumer-specific concerns —
 * project/branch resolution, prompts, flag precedence — stay with consumers.
 */

export {
  type ComputeAppManifest,
  type DetectComputeAppInput,
  type DetectedComputeApp,
  detectComputeApp,
} from "./detect-app.ts";
export {
  type DetectComputeRepositoryInput,
  type DetectComputeRepositoryResult,
  type DetectedComputeRepositoryApp,
  type DetectedPackageManager,
  detectComputeRepository,
} from "./detect-repository.ts";
export {
  ASTRO_CONFIG_FILENAMES,
  CONFIG_BACKED_BUILD_TYPES,
  type ConfigBackedBuildType,
  defaultHttpPortForBuildType,
  ENTRYPOINT_BUILD_TYPES,
  FRAMEWORK_KEYS,
  FRAMEWORKS,
  type FrameworkBuildType,
  type FrameworkDescriptor,
  frameworkByKey,
  frameworkFromAlias,
  isConfigBackedBuildType,
  LOCAL_DEV_BUILD_TYPES,
  NEXT_CONFIG_FILENAMES,
  NUXT_CONFIG_FILENAMES,
  SVELTE_CONFIG_FILENAMES,
} from "./frameworks.ts";
export {
  COMPUTE_CONFIG_JSON_SCHEMA,
  COMPUTE_CONFIG_JSON_SCHEMA_URL,
} from "./json-schema.ts";
export {
  COMPUTE_CONFIG_FILENAME,
  COMPUTE_CONFIG_FILENAMES,
  COMPUTE_CONFIG_JSON_FILENAME,
  ComputeConfigAmbiguousError,
  type ComputeConfigError,
  ComputeConfigLoadError,
  findComputeConfigCandidates,
  findComputeConfigDir,
  loadComputeConfig,
} from "./load.ts";
export {
  ComputeConfigInvalidError,
  type ComputeConfigTargetError,
  ComputeConfigTargetRequiredError,
  ComputeConfigTargetUnknownError,
  type ComputeDeployTarget,
  type ComputeDeployTargetBuild,
  computeTargetAppDir,
  inferComputeTargetFromCwd,
  type LoadedComputeConfig,
  normalizeComputeConfig,
  selectComputeDeployTarget,
} from "./normalize.ts";
export {
  serializeComputeConfig,
  serializeComputeConfigJson,
} from "./serialize.ts";
export { resolveSourceRoot, sourceRootLineage } from "./source-root.ts";
export {
  COMPUTE_FRAMEWORKS,
  COMPUTE_REGIONS,
  type ComputeAppConfig,
  type ComputeBuildConfig,
  type ComputeConfig,
  type ComputeConfigDefaults,
  type ComputeEnvConfig,
  type ComputeFramework,
  type ComputeRegion,
  defineComputeConfig,
} from "./types.ts";
