import type { BuildArtifact } from "./build-strategy.ts";
import type {
  AppInfo,
  DeploymentInfo,
  ProjectInfo,
  RegionInfo,
} from "./types.ts";

export interface DeployProgress {
  onBuildStart?(): void;
  onBuildComplete?(artifact: BuildArtifact): void;
  onArchiveCreating?(): void;
  onArchiveReady?(sizeBytes: number): void;
  onDeploymentCreated?(deploymentId: string): void;
  onUploadStart?(): void;
  onUploadComplete?(): void;
  onStartRequested?(): void;
  onStatusChange?(status: string): void;
  onRunning?(deploymentUrl: string): void;
  onPromoteStart?(): void;
  onPromoted?(appEndpointDomain: string): void;
  onPromoteFailed?(error?: Error): void;
  onOldDeploymentStopping?(deploymentId: string): void;
  onOldDeploymentStopped?(deploymentId: string): void;
  onOldDeploymentStopFailed?(deploymentId: string): void;
  onOldDeploymentDeleting?(deploymentId: string): void;
  onOldDeploymentDeleted?(deploymentId: string): void;
  onOldDeploymentDeleteFailed?(deploymentId: string): void;
  onCleanupDanglingDeployment?(deploymentId: string): void;
  onCleanupDanglingDeploymentComplete?(deploymentId: string): void;
  onCleanupDanglingDeploymentFailed?(deploymentId: string): void;
}

export interface PromoteProgress {
  onDeploymentStarting?(deploymentId: string): void;
  onDeploymentStartRequested?(): void;
  onStatusChange?(status: string): void;
  onDeploymentRunning?(): void;
  onPromoteStart?(): void;
  onPromoted?(appEndpointDomain: string): void;
  onPromoteFailed?(error?: Error): void;
}

export interface DeployInteraction {
  selectProject?(projects: ProjectInfo[]): Promise<string>;
  selectApp?(apps: AppInfo[]): Promise<string | null>;
  provideAppName?(): Promise<string>;
  selectRegion?(regions: RegionInfo[]): Promise<string | undefined>;
}
export interface UpdateEnvProgress {
  onDeploymentCreated?(deploymentId: string): void;
  onStartRequested?(): void;
  onStatusChange?(status: string): void;
  onRunning?(deploymentUrl: string): void;
}
export interface DestroyDeploymentInteraction {
  selectDeployment?(deployments: DeploymentInfo[]): Promise<string>;
}

export interface DestroyDeploymentProgress {
  onStopRequested?(deploymentId: string): void;
  onStopped?(deploymentId: string): void;
  onDeleted?(deploymentId: string): void;
}
export interface DestroyAppProgress {
  onStoppingDeployments?(deploymentIds: string[]): void;
  onDeploymentStopped?(deploymentId: string): void;
  onAllDeploymentsStopped?(): void;
  onDeletingDeployments?(deploymentIds: string[]): void;
  onDeploymentDeleted?(deploymentId: string): void;
  onAllDeploymentsDeleted?(): void;
  onAppDeleted?(appId: string): void;
}
