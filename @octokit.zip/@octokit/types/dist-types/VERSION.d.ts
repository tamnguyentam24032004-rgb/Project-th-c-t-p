export declare const VERSION = "18.0.0";
