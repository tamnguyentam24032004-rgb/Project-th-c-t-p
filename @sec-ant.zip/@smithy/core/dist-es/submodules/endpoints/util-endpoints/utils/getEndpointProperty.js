export { getEndpointProperty } from "./getEndpointProperties";
