export const debugId = "endpoints";
