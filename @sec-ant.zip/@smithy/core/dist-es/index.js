export { getSmithyContext } from "@smithy/core/transport";
export { getHttpAuthSchemeEndpointRuleSetPlugin, getHttpAuthSchemePlugin, httpAuthSchemeEndpointRuleSetMiddlewareOptions, httpAuthSchemeMiddleware, httpAuthSchemeMiddlewareOptions, } from "./legacy-root-exports/middleware-http-auth-scheme";
export { getHttpSigningPlugin, httpSigningMiddleware, httpSigningMiddlewareOptions, } from "./legacy-root-exports/middleware-http-signing";
export { normalizeProvider } from "./normalizeProvider";
export { createPaginator } from "./legacy-root-exports/pagination/createPaginator";
export { requestBuilder } from "@smithy/core/protocols";
export { setFeature } from "./setFeature";
export { DefaultIdentityProviderConfig, EXPIRATION_MS, HttpApiKeyAuthSigner, HttpBearerAuthSigner, NoAuthSigner, createIsIdentityExpiredFunction, doesIdentityRequireRefresh, isIdentityExpired, memoizeIdentityProvider, } from "./legacy-root-exports/util-identity-and-auth";
