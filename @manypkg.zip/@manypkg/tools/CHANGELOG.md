# @manypkg/tools

## 2.1.2

### Patch Changes

- [#271](https://github.com/Thinkmill/manypkg/pull/271) [`4b93c03`](https://github.com/Thinkmill/manypkg/commit/4b93c039aef8ff2dbb61036a140e409c679b3d65) Thanks [@bluwy](https://github.com/bluwy)! - Refactor yaml parsing to use the `yaml` package

## 2.1.1

### Patch Changes

- [#266](https://github.com/Thinkmill/manypkg/pull/266) [`8c4e03b`](https://github.com/Thinkmill/manypkg/commit/8c4e03bba4d551bc9fd1a50581a1fec1e4717985) Thanks [@MatthieuMordrel](https://github.com/MatthieuMordrel)! - Support object-form workspaces in `BunTool` to handle `catalog` usage

## 2.1.0

### Minor Changes

- [#254](https://github.com/Thinkmill/manypkg/pull/254) [`2c06ac0`](https://github.com/Thinkmill/manypkg/commit/2c06ac09397b825dc3cae3c29a1f08bbd09a4ab1) Thanks [@cjkihl](https://github.com/cjkihl)! - Add Bun support

## 2.0.0

### Major Changes

- [#220](https://github.com/Thinkmill/manypkg/pull/220) [`28c3ff4`](https://github.com/Thinkmill/manypkg/commit/28c3ff4bd091565f480e00f407c3f4ebea3536a5) Thanks [@benmccann](https://github.com/benmccann)! - Return values became serializable again. An identifier for the detected tool is returned instead of an instance of a `Tool` object.

- [#250](https://github.com/Thinkmill/manypkg/pull/250) [`3cf8c4e`](https://github.com/Thinkmill/manypkg/commit/3cf8c4e5d49fa703df73eafd26c730491908de75) Thanks [@Andarist](https://github.com/Andarist)! - Fixed an issue with projects using npm workspaces being recognized as yarn projects

- [#242](https://github.com/Thinkmill/manypkg/pull/242) [`1763058`](https://github.com/Thinkmill/manypkg/commit/1763058f9e6a1e85e5720656301d18ca10bda426) Thanks [@spanishpear](https://github.com/spanishpear)! - This package is now published as a [pure ESM package](https://gist.github.com/sindresorhus/a39789f98801d908bbc7ff3ecc99d99c).

- [#245](https://github.com/Thinkmill/manypkg/pull/245) [`a00f5f7`](https://github.com/Thinkmill/manypkg/commit/a00f5f7179cbe0ba60d7d8e0c47c512b67712da2) Thanks [@Andarist](https://github.com/Andarist)! - Drop support for Bolt

- [#244](https://github.com/Thinkmill/manypkg/pull/244) [`f29df03`](https://github.com/Thinkmill/manypkg/commit/f29df03867a909c644e4838d62997427aeadc079) Thanks [@Andarist](https://github.com/Andarist)! - Add `"engines"` field for explicit node version support. The supported node versions are `>=20.0.0`.

### Minor Changes

- [#232](https://github.com/Thinkmill/manypkg/pull/232) [`ceeb7cb`](https://github.com/Thinkmill/manypkg/commit/ceeb7cb634cccdbad57ae830823c96f2d5674ca3) Thanks [@VanTanev](https://github.com/VanTanev)! - Replace the `fast-glob` dependency with `tinyglobby`

## 1.1.2

### Patch Changes

- [#214](https://github.com/Thinkmill/manypkg/pull/214) [`66cdbc0`](https://github.com/Thinkmill/manypkg/commit/66cdbc0ab4f493351724b05189dc89d51d4dadf6) Thanks [@benmccann](https://github.com/benmccann)! - Replace `globby` with `fast-glob` to remove extra dependencies

- [#213](https://github.com/Thinkmill/manypkg/pull/213) [`18c0ce3`](https://github.com/Thinkmill/manypkg/commit/18c0ce3667192e5128d8962267aff7e61cce23a4) Thanks [@benmccann](https://github.com/benmccann)! - Replace `read-yaml-file` with `js-yaml`

- [#212](https://github.com/Thinkmill/manypkg/pull/212) [`c0a5e5d`](https://github.com/Thinkmill/manypkg/commit/c0a5e5dcd096898fa1c196d9bbe19587055e2924) Thanks [@benmccann](https://github.com/benmccann)! - Remove fs-extra from dependencies

## 1.1.1

### Patch Changes

- [#208](https://github.com/Thinkmill/manypkg/pull/208) [`361a34f`](https://github.com/Thinkmill/manypkg/commit/361a34faac94f7a954bbe00321647fc99ae76c17) Thanks [@benmccann](https://github.com/benmccann)! - Add git repository info to `package.json`

## 1.1.0

### Minor Changes

- [#174](https://github.com/Thinkmill/manypkg/pull/174) [`de0fff3`](https://github.com/Thinkmill/manypkg/commit/de0fff37af9e6dc21b75b7115381483c1e85b8a7) Thanks [@steve-taylor](https://github.com/steve-taylor)! - Restored support for Bolt monorepos.

## 1.0.0

### Major Changes

- [#151](https://github.com/Thinkmill/manypkg/pull/151) [`a01efc9`](https://github.com/Thinkmill/manypkg/commit/a01efc9c25900b7d21b6d517a2021b021f8b3922) Thanks [@elliot-nelson](https://github.com/elliot-nelson)! - Introduces a new `Tool` API that provides key functions related to a specific implementation of a monorepo, like `isMonorepoRoot` and `getPackages`. Existing tool implementations in manypkg have been converted to use this new interface.
