export { fromProcess } from "./fromProcess";
