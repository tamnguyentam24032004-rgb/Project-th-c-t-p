import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
/**
 * The pinned floci release alchemy ships: upstream + the alchemy patch
 * set, built and published by the alchemy-run/floci fork's release
 * workflow. Bumping this pin (with a new `x.y.z-alchemy.N` tag) is how an
 * emulator change reaches users.
 */
export declare const DEFAULT_FLOCI_IMAGE = "ghcr.io/alchemy-run/floci:1.6.0-alchemy.11";
/** Default gateway port (LocalStack-compatible). */
export declare const DEFAULT_FLOCI_PORT = 4566;
/**
 * ELB listener ports published on the managed container. Floci's ELBv2
 * data plane serves each listener on the listener's OWN port inside the
 * container (see floci's ports doc) — its `*.elb.localhost.floci.io` DNS
 * resolves to 127.0.0.1, so the port must be published for the emulated
 * load balancer to be reachable from the host. Ports already taken on the
 * host are skipped (the gateway still works without them). A warning is
 * emitted only when the caller asked for those ports via
 * {@link FlociConfig.elbListenerPorts} — the default 80/443 publish is
 * opportunistic and a taken privileged port is the common case on a
 * developer machine, not a problem.
 */
export declare const DEFAULT_ELB_LISTENER_PORTS: number[];
/**
 * Ports published for floci's emulated CloudFront edge. Each emulated
 * distribution is served on one of these as plain HTTP, so `alchemy dev`
 * hands out a `router.url` a browser can open — a distribution's
 * `*.cloudfront.net` domain resolves to nothing on a developer's machine.
 * The emulator assigns a port per distribution and reports it back; it can
 * only use ports the container actually published, so the resolved list is
 * passed in as `FLOCI_SERVICES_CLOUDFRONT_EDGE_PORTS`. Taken host ports are
 * skipped, exactly like the ELB listener ports above.
 */
export declare const DEFAULT_CLOUDFRONT_EDGE_PORTS: number[];
/** Default name of the managed container. */
export declare const DEFAULT_CONTAINER_NAME = "alchemy-floci";
/**
 * Stable host path of the emulator's self-signed CA bundle, refreshed by
 * {@link ensureFloci} on every successful health check (the CA is minted
 * inside the container, so it changes whenever the container is recreated).
 * Home-anchored (not cwd-relative) so every process in a dev session — test
 * runner, RPC sidecars, workerd children — resolves the same file; consumers
 * point TLS trust at it (e.g. `NODE_EXTRA_CA_CERTS`, which the local workerd
 * runtime folds into its outbound `trustedCertificates`).
 */
export declare const FLOCI_CA_PATH: string;
/**
 * Host directory mounted at the container's TLS dir (`/app/data/tls`) so
 * the self-signed CA (which floci reuses when the files already exist)
 * SURVIVES container recreations. Without it, every recreate — an image
 * bump, a port-config change, a Docker daemon restart — mints a fresh CA,
 * and every process that loaded the previous bundle (workerd trust stores
 * read once at spawn) fails TLS against the emulator until restarted.
 */
export declare const FLOCI_TLS_DIR: string;
declare const FlociError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "FlociError";
} & Readonly<A>;
export declare class FlociError extends FlociError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export interface FlociConfig {
    /**
     * Image to run when the emulator is not already serving.
     * Resolution order: `ALCHEMY_FLOCI_IMAGE` env var, this field,
     * {@link DEFAULT_FLOCI_IMAGE}.
     */
    readonly image?: string | undefined;
    /**
     * Gateway port on the host.
     * @default 4566
     */
    readonly port?: number | undefined;
    /**
     * Name of the managed container (stable so `docker start` can revive a
     * stopped one).
     * @default "alchemy-floci"
     */
    readonly containerName?: string | undefined;
    /**
     * Host directory persisted into the container's data dir. Omit for
     * floci's default in-memory storage (state lives as long as the
     * container).
     */
    readonly storageDir?: string | undefined;
    /**
     * Mount the host Docker socket so floci's container-backed engines
     * (Lambda, ECS, EC2, RDS, ElastiCache) work.
     * @default true
     */
    readonly dockerSocket?: boolean | undefined;
    /**
     * Extra environment variables for the emulator (e.g.
     * `FLOCI_SERVICES_LAMBDA_HOT_RELOAD_ENABLED`).
     */
    readonly env?: Record<string, string> | undefined;
    /**
     * ELB listener ports to publish on the managed container (floci's ALB
     * data plane serves each listener on the listener's own port). Ports
     * already taken on the host are skipped (with a warning only when this
     * field is set — the default 80/443 publish is opportunistic).
     * @default [80, 443]
     */
    readonly elbListenerPorts?: readonly number[] | undefined;
    /**
     * Ports to publish for the emulated CloudFront edge (floci serves each
     * distribution on its own port). Ports already taken on the host are
     * skipped; an empty result turns the feature off in the emulator so it
     * never binds a port nothing can reach.
     * @default 9500-9519
     */
    readonly cloudfrontEdgePorts?: readonly number[] | undefined;
    /**
     * How long to wait for the emulator to become healthy after starting it
     * (first run includes the image pull).
     * @default 180 seconds
     */
    readonly readinessTimeout?: Duration.Input | undefined;
}
/** A running (or reused) emulator. */
export interface FlociInstance {
    /** Gateway endpoint, e.g. `http://localhost:4566`. */
    readonly endpoint: string;
    /**
     * Whether this manager started the container (`false` when something was
     * already serving on the endpoint — a dev-mode JVM, a hand-run
     * container, or a previous session's container).
     */
    readonly managed: boolean;
    /** Container name when {@link managed} is true. */
    readonly containerName?: string | undefined;
}
/**
 * Whether anything answers HTTP on the endpoint. Any response — even an
 * error status — counts as serving; only a transport failure means down.
 */
export declare const isServing: (endpoint: string) => Effect.Effect<boolean>;
/** Fail unless `GET /_floci/health` answers 200. */
export declare const checkHealth: (endpoint: string) => Effect.Effect<void, FlociError>;
/** Resolve the image to run: env override, config, pinned default. */
export declare const resolveImage: (config?: FlociConfig) => Effect.Effect<string>;
export declare const ensureFloci: (config?: FlociConfig) => Effect.Effect<FlociInstance, FlociError>;
/** Stop (not remove) the managed container. */
export declare const stopFloci: (containerName?: string) => Effect.Effect<void, FlociError>;
/** Remove the managed container (and its in-memory state). */
export declare const destroyFloci: (containerName?: string) => Effect.Effect<void, FlociError>;
/** Tail of the managed container's logs. */
export declare const flociLogs: (containerName?: string, lines?: number) => Effect.Effect<string, FlociError>;
export {};
//# sourceMappingURL=index.d.ts.map