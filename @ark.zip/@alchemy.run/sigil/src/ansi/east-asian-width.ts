// East Asian Width lookup, plus string-width's full-width test.
// Ported from `get-east-asian-width` and `is-fullwidth-code-point`
// (MIT, Sindre Sorhus). The range tables are generated from Unicode data.

export type EastAsianWidthType =
  | "ambiguous"
  | "fullwidth"
  | "halfwidth"
  | "narrow"
  | "neutral"
  | "wide";

// Binary search on a sorted flat array of inclusive [start, end] pairs.
const isInRange = (ranges: readonly number[], codePoint: number): boolean => {
  let low = 0;
  let high = Math.floor(ranges.length / 2) - 1;
  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    const i = mid * 2;
    if (codePoint < ranges[i]!) {
      high = mid - 1;
    } else if (codePoint > ranges[i + 1]!) {
      low = mid + 1;
    } else {
      return true;
    }
  }

  return false;
};

export const ambiguousMinimalCodePoint = 161;
export const ambiguousMaximumCodePoint = 1114109;
export const ambiguousRanges: readonly number[] = [
  161, 161, 164, 164, 167, 168, 170, 170, 173, 174, 176, 180, 182, 186, 188, 191, 198, 198, 208,
  208, 215, 216, 222, 225, 230, 230, 232, 234, 236, 237, 240, 240, 242, 243, 247, 250, 252, 252,
  254, 254, 257, 257, 273, 273, 275, 275, 283, 283, 294, 295, 299, 299, 305, 307, 312, 312, 319,
  322, 324, 324, 328, 331, 333, 333, 338, 339, 358, 359, 363, 363, 462, 462, 464, 464, 466, 466,
  468, 468, 470, 470, 472, 472, 474, 474, 476, 476, 593, 593, 609, 609, 708, 708, 711, 711, 713,
  715, 717, 717, 720, 720, 728, 731, 733, 733, 735, 735, 768, 879, 913, 929, 931, 937, 945, 961,
  963, 969, 1025, 1025, 1040, 1103, 1105, 1105, 8208, 8208, 8211, 8214, 8216, 8217, 8220, 8221,
  8224, 8226, 8228, 8231, 8240, 8240, 8242, 8243, 8245, 8245, 8251, 8251, 8254, 8254, 8308, 8308,
  8319, 8319, 8321, 8324, 8364, 8364, 8451, 8451, 8453, 8453, 8457, 8457, 8467, 8467, 8470, 8470,
  8481, 8482, 8486, 8486, 8491, 8491, 8531, 8532, 8539, 8542, 8544, 8555, 8560, 8569, 8585, 8585,
  8592, 8601, 8632, 8633, 8658, 8658, 8660, 8660, 8679, 8679, 8704, 8704, 8706, 8707, 8711, 8712,
  8715, 8715, 8719, 8719, 8721, 8721, 8725, 8725, 8730, 8730, 8733, 8736, 8739, 8739, 8741, 8741,
  8743, 8748, 8750, 8750, 8756, 8759, 8764, 8765, 8776, 8776, 8780, 8780, 8786, 8786, 8800, 8801,
  8804, 8807, 8810, 8811, 8814, 8815, 8834, 8835, 8838, 8839, 8853, 8853, 8857, 8857, 8869, 8869,
  8895, 8895, 8978, 8978, 9312, 9449, 9451, 9547, 9552, 9587, 9600, 9615, 9618, 9621, 9632, 9633,
  9635, 9641, 9650, 9651, 9654, 9655, 9660, 9661, 9664, 9665, 9670, 9672, 9675, 9675, 9678, 9681,
  9698, 9701, 9711, 9711, 9733, 9734, 9737, 9737, 9742, 9743, 9756, 9756, 9758, 9758, 9792, 9792,
  9794, 9794, 9824, 9825, 9827, 9829, 9831, 9834, 9836, 9837, 9839, 9839, 9886, 9887, 9919, 9919,
  9926, 9933, 9935, 9939, 9941, 9953, 9955, 9955, 9960, 9961, 9963, 9969, 9972, 9972, 9974, 9977,
  9979, 9980, 9982, 9983, 10045, 10045, 10102, 10111, 11094, 11097, 12872, 12879, 57344, 63743,
  65024, 65039, 65533, 65533, 127232, 127242, 127248, 127277, 127280, 127337, 127344, 127373,
  127375, 127376, 127387, 127404, 917760, 917999, 983040, 1048573, 1048576, 1114109,
];

export const fullwidthMinimalCodePoint = 12288;
export const fullwidthMaximumCodePoint = 65510;
export const fullwidthRanges: readonly number[] = [12288, 12288, 65281, 65376, 65504, 65510];

export const halfwidthMinimalCodePoint = 8361;
export const halfwidthMaximumCodePoint = 65518;
export const halfwidthRanges: readonly number[] = [
  8361, 8361, 65377, 65470, 65474, 65479, 65482, 65487, 65490, 65495, 65498, 65500, 65512, 65518,
];

export const narrowMinimalCodePoint = 32;
export const narrowMaximumCodePoint = 10630;
export const narrowRanges: readonly number[] = [
  32, 126, 162, 163, 165, 166, 172, 172, 175, 175, 10214, 10221, 10629, 10630,
];

export const wideMinimalCodePoint = 4352;
export const wideMaximumCodePoint = 262141;
export const wideRanges: readonly number[] = [
  4352, 4447, 8986, 8987, 9001, 9002, 9193, 9196, 9200, 9200, 9203, 9203, 9725, 9726, 9748, 9749,
  9776, 9783, 9800, 9811, 9855, 9855, 9866, 9871, 9875, 9875, 9889, 9889, 9898, 9899, 9917, 9918,
  9924, 9925, 9934, 9934, 9940, 9940, 9962, 9962, 9970, 9971, 9973, 9973, 9978, 9978, 9981, 9981,
  9989, 9989, 9994, 9995, 10024, 10024, 10060, 10060, 10062, 10062, 10067, 10069, 10071, 10071,
  10133, 10135, 10160, 10160, 10175, 10175, 11035, 11036, 11088, 11088, 11093, 11093, 11904, 11929,
  11931, 12019, 12032, 12245, 12272, 12287, 12289, 12350, 12353, 12438, 12441, 12543, 12549, 12591,
  12593, 12686, 12688, 12773, 12783, 12830, 12832, 12871, 12880, 42124, 42128, 42182, 43360, 43388,
  44032, 55203, 63744, 64255, 65040, 65049, 65072, 65106, 65108, 65126, 65128, 65131, 94176, 94180,
  94192, 94198, 94208, 101589, 101631, 101662, 101760, 101874, 110576, 110579, 110581, 110587,
  110589, 110590, 110592, 110882, 110898, 110898, 110928, 110930, 110933, 110933, 110948, 110951,
  110960, 111355, 119552, 119638, 119648, 119670, 126980, 126980, 127183, 127183, 127374, 127374,
  127377, 127386, 127488, 127490, 127504, 127547, 127552, 127560, 127568, 127569, 127584, 127589,
  127744, 127776, 127789, 127797, 127799, 127868, 127870, 127891, 127904, 127946, 127951, 127955,
  127968, 127984, 127988, 127988, 127992, 128062, 128064, 128064, 128066, 128252, 128255, 128317,
  128331, 128334, 128336, 128359, 128378, 128378, 128405, 128406, 128420, 128420, 128507, 128591,
  128640, 128709, 128716, 128716, 128720, 128722, 128725, 128728, 128732, 128735, 128747, 128748,
  128756, 128764, 128992, 129003, 129008, 129008, 129292, 129338, 129340, 129349, 129351, 129535,
  129648, 129660, 129664, 129674, 129678, 129734, 129736, 129736, 129741, 129756, 129759, 129770,
  129775, 129784, 131072, 196605, 196608, 262141,
];

const commonCjkCodePoint = 0x4e_00;
const [wideFastPathStart, wideFastPathEnd] = /* #__PURE__ */ findWideFastPathRange(wideRanges);

// Use a hot-path range so common `isWide` calls can skip binary search.
// The range containing U+4E00 covers common CJK ideographs;
// fallback to the largest range for resilience to Unicode table changes.
function findWideFastPathRange(ranges: readonly number[]): [number, number] {
  let fastPathStart = ranges[0]!;
  let fastPathEnd = ranges[1]!;

  for (let index = 0; index < ranges.length; index += 2) {
    const start = ranges[index]!;
    const end = ranges[index + 1]!;

    if (commonCjkCodePoint >= start && commonCjkCodePoint <= end) {
      return [start, end];
    }

    if (end - start > fastPathEnd - fastPathStart) {
      fastPathStart = start;
      fastPathEnd = end;
    }
  }

  return [fastPathStart, fastPathEnd];
}

export const isAmbiguous = (codePoint: number): boolean => {
  if (codePoint < ambiguousMinimalCodePoint || codePoint > ambiguousMaximumCodePoint) {
    return false;
  }

  return isInRange(ambiguousRanges, codePoint);
};

export const isFullWidth = (codePoint: number): boolean => {
  if (codePoint < fullwidthMinimalCodePoint || codePoint > fullwidthMaximumCodePoint) {
    return false;
  }

  return isInRange(fullwidthRanges, codePoint);
};

const isHalfWidth = (codePoint: number): boolean => {
  if (codePoint < halfwidthMinimalCodePoint || codePoint > halfwidthMaximumCodePoint) {
    return false;
  }

  return isInRange(halfwidthRanges, codePoint);
};

const isNarrow = (codePoint: number): boolean => {
  if (codePoint < narrowMinimalCodePoint || codePoint > narrowMaximumCodePoint) {
    return false;
  }

  return isInRange(narrowRanges, codePoint);
};

export const isWide = (codePoint: number): boolean => {
  if (codePoint >= wideFastPathStart && codePoint <= wideFastPathEnd) {
    return true;
  }

  if (codePoint < wideMinimalCodePoint || codePoint > wideMaximumCodePoint) {
    return false;
  }

  return isInRange(wideRanges, codePoint);
};

export function getCategory(codePoint: number): EastAsianWidthType {
  if (isAmbiguous(codePoint)) {
    return "ambiguous";
  }

  if (isFullWidth(codePoint)) {
    return "fullwidth";
  }

  if (isHalfWidth(codePoint)) {
    return "halfwidth";
  }

  if (isNarrow(codePoint)) {
    return "narrow";
  }

  if (isWide(codePoint)) {
    return "wide";
  }

  return "neutral";
}

export function eastAsianWidthType(codePoint: number): EastAsianWidthType {
  return getCategory(codePoint);
}

export function eastAsianWidth(
  codePoint: number,
  { ambiguousAsWide = false }: { ambiguousAsWide?: boolean } = {},
): 1 | 2 {
  if (isFullWidth(codePoint) || isWide(codePoint) || (ambiguousAsWide && isAmbiguous(codePoint))) {
    return 2;
  }

  return 1;
}

/**
Grapheme-cluster width test shared by the tokenizer (slice/clip path): the
base code point's East Asian Width, plus emoji presentation rules.
*/
export function isFullwidthGrapheme(grapheme: string, baseCodePoint: number): boolean {
  if (isFullwidthCodePoint(baseCodePoint)) return true;
  // Variation Selector 16 forces emoji presentation (2 columns wide)
  if (grapheme.includes("\uFE0F")) return true;
  // Regional indicator pairs form flag emoji (2 columns wide)
  if (baseCodePoint >= 0x1f1e6 && baseCodePoint <= 0x1f1ff) return true;
  return false;
}

/**
Wide code points not covered by string-width's CJKT script regex or emoji
regex — the fallback bucket of its block parser. A disjoint decomposition of
the `wide` table above, kept alongside it so the width data lives in one
module.
*/
export const isWideNotCJKTNotEmoji = (x: number): boolean => {
  return (
    x === 0x231b ||
    x === 0x2329 ||
    (x >= 0x2ff0 && x <= 0x2fff) ||
    (x >= 0x3001 && x <= 0x303e) ||
    (x >= 0x3099 && x <= 0x30ff) ||
    (x >= 0x3105 && x <= 0x312f) ||
    (x >= 0x3131 && x <= 0x318e) ||
    (x >= 0x3190 && x <= 0x31e3) ||
    (x >= 0x31ef && x <= 0x321e) ||
    (x >= 0x3220 && x <= 0x3247) ||
    (x >= 0x3250 && x <= 0x4dbf) ||
    (x >= 0xfe10 && x <= 0xfe19) ||
    (x >= 0xfe30 && x <= 0xfe52) ||
    (x >= 0xfe54 && x <= 0xfe66) ||
    (x >= 0xfe68 && x <= 0xfe6b) ||
    (x >= 0x1f200 && x <= 0x1f202) ||
    (x >= 0x1f210 && x <= 0x1f23b) ||
    (x >= 0x1f240 && x <= 0x1f248) ||
    (x >= 0x20000 && x <= 0x2fffd) ||
    (x >= 0x30000 && x <= 0x3fffd)
  );
};

export function isFullwidthCodePoint(codePoint: number): boolean {
  if (!Number.isInteger(codePoint)) {
    return false;
  }

  return isFullWidth(codePoint) || isWide(codePoint);
}
