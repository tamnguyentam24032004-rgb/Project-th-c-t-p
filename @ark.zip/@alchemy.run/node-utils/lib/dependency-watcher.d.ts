import { type ChokidarOptions } from "chokidar";
export interface DependencyChange {
    readonly paths: ReadonlySet<string>;
}
export type DependencyChangeListener = (change: DependencyChange) => void;
export interface DependencyWatcherOptions {
    /** Chokidar options passed to the file watcher. */
    readonly watch?: ChokidarOptions | undefined;
    readonly debounceMs?: number | undefined;
}
/**
 * Watches an explicit set of absolute file paths and delivers debounced
 * batches only when their contents change. Chokidar follows editor atomic-save
 * replacements without polling by default. The set is replaced wholesale
 * with {@link set}, so the watcher always mirrors exactly the files the caller
 * currently depends on.
 */
export declare class DependencyWatcher {
    #private;
    constructor(options?: DependencyWatcherOptions);
    get dependencies(): ReadonlySet<string>;
    subscribe(listener: DependencyChangeListener): () => void;
    /** Replace the watched set with `dependencies` (absolute paths). */
    set(dependencies: ReadonlySet<string>): void;
    close(): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
//# sourceMappingURL=dependency-watcher.d.ts.map