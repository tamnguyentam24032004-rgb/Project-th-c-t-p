import { type DependencyChangeListener, type DependencyWatcherOptions } from "./dependency-watcher.ts";
export interface BunImportTrackerOptions extends DependencyWatcherOptions {
    /**
     * Directory whose modules belong to the tracked graph. Files outside it and
     * anything under a `node_modules` directory load untouched.
     */
    readonly root: string;
}
/**
 * Records every project-local module Bun loads after registration and watches
 * those files for changes.
 *
 * Bun has no loader hooks that can evict or re-namespace an evaluated module,
 * so unlike Node's {@link ImportWatcher} this cannot import a fresh
 * generation in-process. A runtime `Bun.plugin` `onLoad` hook is used purely
 * as a dependency probe: it hands the source back unchanged with the loader
 * Bun would have picked itself. Callers react to a change by exiting so a
 * supervisor can start a fresh process.
 */
export declare class BunImportTracker {
    #private;
    constructor(options: BunImportTrackerOptions);
    get dependencies(): ReadonlySet<string>;
    subscribe(listener: DependencyChangeListener): () => void;
    /** Stops watching. The load hook stays registered but only echoes sources. */
    close(): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
export declare const trackBunImports: (options: BunImportTrackerOptions) => BunImportTracker;
//# sourceMappingURL=watch-import-bun.d.ts.map