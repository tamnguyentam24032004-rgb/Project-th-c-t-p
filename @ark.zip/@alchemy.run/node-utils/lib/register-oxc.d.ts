export interface OxcLoaderOptions {
    /**
     * Additional package export conditions used during module resolution.
     * They are made available alongside Node's ambient conditions to both the
     * TypeScript-aware resolver and Node's package exports resolver.
     */
    readonly conditions?: ReadonlyArray<string> | undefined;
    /**
     * Honour `tsconfig.json` discovered upward from each file: compiler
     * options for the transform, `paths`/`baseUrl` aliases for resolution.
     * @default true
     */
    readonly tsconfig?: boolean | undefined;
    /** Controls which file URLs belong to the fresh import graph. */
    readonly shouldInvalidate?: ((url: string, parentURL: string | undefined) => boolean) | undefined;
    /**
     * Limits transformation to matching absolute file paths; everything else
     * loads through Node untouched. Lets a published install transpile only
     * the user's own TypeScript while alchemy and its dependencies run their
     * built JavaScript.
     */
    readonly filter?: ((path: string) => boolean) | undefined;
    /**
     * On-disk cache of Oxc output shared by every process on the machine, so
     * the CLI, its dev exec child and the local-provider sidecars transpile
     * each source file once between them rather than once each. `false`
     * disables it, a string names the directory.
     * @default `$ALCHEMY_TRANSFORM_CACHE` (`0` disables), else a per-user
     * directory under the OS temp directory
     */
    readonly cache?: boolean | string | undefined;
}
export interface RegisterOxcOptions extends OxcLoaderOptions {
    /**
     * Isolates one import graph in the runtime's module cache: every file
     * URL the graph resolves carries this namespace as a query parameter, so
     * the same files import again as fresh modules under a new namespace.
     * This is how `alchemy dev` reloads the user's stack (see
     * `watch-import.ts`); an un-namespaced registration is the process-wide
     * TypeScript loader.
     */
    readonly namespace?: string | undefined;
    /** Called once the runtime loads a file in this registration's graph. */
    readonly onImport?: ((url: string) => void) | undefined;
}
export interface OxcLoader {
    /**
     * Imports a file under this registration's namespace. `specifier` is a
     * file URL, an absolute path, or a path relative to `parentURL`.
     */
    import<T = unknown>(specifier: string, parentURL: string): Promise<T>;
    unregister(): void;
}
/**
 * Registers synchronous Node module hooks that transpile TypeScript with
 * Rolldown's Oxc transformer and resolve it the way TypeScript (and tsx)
 * does. A namespaced registration also provides a scoped import whose
 * namespace propagates through the complete ESM graph.
 */
export declare const registerOxc: (options?: RegisterOxcOptions) => OxcLoader;
//# sourceMappingURL=register-oxc.d.ts.map