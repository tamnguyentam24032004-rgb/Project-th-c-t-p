declare const KEY_IGNORE: string | symbol;
declare const MODE_IGNORE = "regex";
declare const MODE_CHECK_IGNORE = "checkRegex";
type MatcherMode = typeof MODE_IGNORE | typeof MODE_CHECK_IGNORE;
declare class IgnoreRule {
    readonly pattern: string;
    readonly mark: string | undefined;
    readonly negative: boolean;
    readonly body: string;
    readonly ignoreCase: boolean;
    readonly regexPrefix: string;
    private _regex?;
    private _checkRegex?;
    constructor(pattern: string, mark: string | undefined, body: string, ignoreCase: boolean, negative: boolean, prefix: string);
    get regex(): RegExp;
    get checkRegex(): RegExp;
    _make(mode: MatcherMode, key: "_regex" | "_checkRegex"): RegExp;
}
declare class RuleManager {
    private readonly _ignoreCase;
    _rules: IgnoreRule[];
    private _added;
    constructor(ignoreCase: boolean);
    _add(pattern: string | Ignore | PatternParams): void;
    add(pattern: string | Ignore | PatternParams | readonly (string | Ignore)[]): boolean;
    test(path: string, checkUnignored: boolean, mode: MatcherMode): IgnoreTestResult;
}
declare class Ignore {
    readonly [KEY_IGNORE]?: true | undefined;
    readonly _rules: RuleManager;
    private readonly _strictPathCheck;
    private _ignoreCache;
    private _testCache;
    constructor({ ignorecase, ignoreCase, allowRelativePaths, }?: IgnoreOptions);
    _initCache(): void;
    add(pattern: string | Ignore | readonly (string | Ignore)[] | PatternParams): this;
    addPattern(pattern: string | readonly string[]): this;
    _test(originalPath: string, cache: Record<string, IgnoreTestResult>, checkUnignored: boolean, slices?: string[]): IgnoreTestResult;
    checkIgnore(path: string): IgnoreTestResult;
    _t(path: string, cache: Record<string, IgnoreTestResult>, checkUnignored: boolean, slices?: string[]): IgnoreTestResult;
    ignores(path: string): boolean;
    createFilter(): (path: string) => boolean;
    filter(paths: readonly string[]): string[];
    test(path: string): IgnoreTestResult;
}
declare const isPathValid: (path: string) => boolean;
declare const _default: (options?: IgnoreOptions) => IgnoreInstance;
export default _default;
export { Ignore, isPathValid };
type Pathname = string;
interface PatternParams {
    pattern: string;
    mark?: string;
}
interface IgnoreTestResult {
    ignored: boolean;
    unignored: boolean;
    rule?: IgnoreRule;
}
export interface IgnoreOptions {
    ignorecase?: boolean;
    /** For compatibility. */
    ignoreCase?: boolean;
    allowRelativePaths?: boolean;
}
export interface IgnoreInstance {
    add(patterns: string | IgnoreInstance | readonly (string | IgnoreInstance)[] | PatternParams): this;
    filter(pathnames: readonly Pathname[]): Pathname[];
    createFilter(): (pathname: Pathname) => boolean;
    ignores(pathname: Pathname): boolean;
    test(pathname: Pathname): {
        ignored: boolean;
        unignored: boolean;
        rule?: {
            pattern: string;
            mark?: string;
            negative: boolean;
        };
    };
    checkIgnore(pathname: Pathname): {
        ignored: boolean;
        unignored: boolean;
        rule?: {
            pattern: string;
            mark?: string;
            negative: boolean;
        };
    };
}
//# sourceMappingURL=ignore.d.ts.map