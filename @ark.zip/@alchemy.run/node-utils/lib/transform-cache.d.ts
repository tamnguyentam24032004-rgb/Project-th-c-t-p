export declare const TRANSFORM_CACHE_ENV = "ALCHEMY_TRANSFORM_CACHE";
/**
 * The directory to use for the given option, or `undefined` when caching is
 * off. `cache: false` and `ALCHEMY_TRANSFORM_CACHE=0` disable it; a string
 * (option or env) names the directory; otherwise the per-user default.
 */
export declare const resolveCacheDirectory: (option: boolean | string | undefined) => string | undefined;
/** One transform's output as handed to {@link TransformCache.set}. */
export interface TransformCacheEntry {
    readonly format: "module" | "commonjs";
    readonly code: string;
    /** Source map JSON, or `undefined` when the transform produced none. */
    readonly map: string | undefined;
}
/** A cache hit: the code, and where its source map lives on disk. */
export interface CachedTransform {
    readonly format: "module" | "commonjs";
    readonly code: string;
    /** Absolute path of the entry's `.map` file, present when it has one. */
    readonly mapFile: string | undefined;
}
/**
 * On-disk cache of Oxc transform output shared by every process on the
 * machine — the `alchemy` CLI, its dev exec child, the local-provider
 * sidecars and dev-server runners all load the same source files, and
 * without this each of them transpiles the whole graph again.
 *
 * Modelled on tsx's file cache: entries are keyed by a hash of the source
 * file's path, size and mtime, the transform options and the resolved
 * tsconfig, so a change to any input is simply a different key; nothing is
 * ever invalidated in place. Size plus nanosecond mtime stands in for the
 * contents so a hit never reads the source.
 *
 * An entry is two files: `<key>.json` with the code, and `<key>.map` with
 * the source map. The map stays on disk and is referenced from the module
 * by path rather than inlined — an inline `data:` map is part of the
 * script's source text, which V8 keeps for the process lifetime; for a
 * graph the size of alchemy's that is hundreds of megabytes per process.
 * Node reads the referenced file synchronously as it compiles the module,
 * so the map is written (atomically) before `set` returns; the code entry
 * is a fire-and-forget write, because a missing one is only a slower
 * cache. Reads are synchronous (the loader hook is). Stale entries are
 * swept by age once per process.
 */
export declare class TransformCache {
    #private;
    constructor(directory: string);
    /** The entry key for these transform inputs. */
    key(parts: ReadonlyArray<string>): string;
    /**
     * The cached transform, or `undefined` on a miss. An entry whose map file
     * has gone (swept, or never landed) is a miss too: the module would
     * otherwise reference a map that is not there.
     */
    get(key: string): CachedTransform | undefined;
    /**
     * Stores one transform. Returns the map file's path once it is on disk,
     * or `undefined` when there is no map or it could not be written — the
     * caller then falls back to inlining it.
     */
    set(key: string, entry: TransformCacheEntry): string | undefined;
}
//# sourceMappingURL=transform-cache.d.ts.map