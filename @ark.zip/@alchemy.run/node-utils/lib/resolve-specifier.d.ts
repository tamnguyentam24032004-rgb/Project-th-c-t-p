/**
 * TypeScript-aware specifier resolution on top of Oxc's resolver, mirroring
 * what tsx layers over Node's resolver:
 *
 * - `tsconfig.json` `paths` / `baseUrl` aliases, discovered per importing file
 * - emitted-extension substitution (`./x.js` → `x.ts`/`x.tsx`, `.mjs` → `.mts`,
 *   `.cjs` → `.cts`, `.jsx` → `.tsx`), TypeScript source winning over an
 *   emitted sibling
 * - extensionless specifiers and directory indexes, TypeScript first
 *
 * Node's own resolver stays the authority: every candidate this class
 * produces is handed back to Node (`nextResolve`) so it decides the format,
 * validates package exports, and reports the canonical error.
 */
export interface SpecifierResolverOptions {
    /** Discover `tsconfig.json` upward from each importing file. */
    readonly tsconfig: boolean;
}
export declare const nodeModulesSegment: string;
/** Local project code: a file path outside every `node_modules` directory. */
export declare const isProjectPath: (filePath: string) => boolean;
/** Whether TypeScript's extension substitution applies to this importer. */
export declare const isTypeScriptPath: (filePath: string) => boolean;
export declare const isFileLikeSpecifier: (specifier: string) => boolean;
/**
 * Splits `?query#fragment` metadata off a specifier. Bare specifiers never
 * carry fragments in Node, so only `?` is honoured there.
 */
export declare const splitSpecifierMetadata: (specifier: string) => {
    specifier: string;
    metadata: string;
};
export declare const filePathOfUrl: (url: string | undefined) => string | undefined;
export declare class SpecifierResolver {
    #private;
    constructor(options: SpecifierResolverOptions);
    /**
     * Resolves `specifier` as imported from `parentPath` to an absolute file
     * path, or `undefined` when Oxc cannot resolve it (Node then reports the
     * error), when it is a builtin, or when a bare specifier lands inside
     * `node_modules` — packages are Node's business, only `paths` aliases
     * that map onto project files are ours.
     */
    resolve(parentPath: string, specifier: string, conditions: ReadonlyArray<string>): string | undefined;
}
//# sourceMappingURL=resolve-specifier.d.ts.map