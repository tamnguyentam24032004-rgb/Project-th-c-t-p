import { type DependencyChangeListener, type DependencyWatcherOptions } from "./dependency-watcher.ts";
import type { OxcLoaderOptions } from "./register-oxc.ts";
export interface ImportGeneration<T> {
    readonly value: T;
    readonly namespace: string;
    readonly dependencies: ReadonlySet<string>;
}
export interface ImportWatcherOptions extends OxcLoaderOptions, DependencyWatcherOptions {
    readonly parentURL: string;
}
/**
 * Imports fresh Node module generations and watches the exact files loaded by
 * the current generation. Bun callers should use `BunImportTracker` from
 * `./watch-import-bun.ts`: Bun cannot evict evaluated modules, so a change
 * there restarts the process instead of importing a new generation.
 */
export declare class ImportWatcher<T = unknown> {
    #private;
    constructor(specifier: string, options: ImportWatcherOptions);
    get dependencies(): ReadonlySet<string>;
    subscribe(listener: DependencyChangeListener): () => void;
    import(): Promise<ImportGeneration<T>>;
    close(): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
export declare const watchImport: <T = unknown>(specifier: string, options: ImportWatcherOptions) => ImportWatcher<T>;
//# sourceMappingURL=watch-import.d.ts.map