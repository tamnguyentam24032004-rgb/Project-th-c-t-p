import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type { Input } from "./Input.ts";
import { type TelemetryLayer } from "./TelemetryRuntime.ts";
export { buildEventTelemetry, provideProcessTelemetry, Telemetry, type TelemetryLayer, } from "./TelemetryRuntime.ts";
/**
 * Install a custom telemetry Layer (any Layer providing a `Tracer`,
 * loggers, and/or metric exporters). It is built once per event into the
 * event's request scope, so scoped exporters flush when the request scope
 * finalizes.
 *
 * Custom layers COMPOSE with the built-in OTLP destinations and with each
 * other: loggers and metric exporters merge; a custom `Tracer` (a single
 * Effect service) replaces the built-in one.
 *
 * The isolate {@link Telemetry} reference stays the bound OTLP reader.
 * The custom Layer is stored on `ctx.telemetry` and merged per event as
 * the override, so `Layer.mergeAll` order with {@link layerOtlp} does not
 * drop logs/metrics.
 *
 * Provide it on the Function/Worker's init Effect (merged into the single
 * `Effect.provide`): building the returned Layer registers the exporter
 * Layer on the current runtime context, where the runtime bridges pick it
 * up per event. Handlers' request-time context is assembled by the bridge,
 * so a plain `Layer.succeed` of the reference on the init Effect would
 * never reach them — the registration is what makes it visible at request
 * time.
 */
export declare const layer: (exporter: TelemetryLayer) => Layer.Layer<never>;
/**
 * A header value: a plain string, a `Redacted` secret, or an Output of
 * either (e.g. an ApiToken's `token` attribute).
 */
export type OtlpHeaderValue = Input<string | Redacted.Redacted<string>>;
/**
 * OTLP configuration for one signal. `url` and header values accept plain
 * values or resource Outputs — they are *bound* onto the host at deploy
 * time like any other binding.
 */
export interface OtlpSignalOptions {
    /** The OTLP/HTTP URL exports for this signal are POSTed to. */
    url: Input<string>;
    /**
     * Headers sent with each export request (e.g. auth tokens). `Redacted`
     * values bind as secrets.
     */
    headers?: Record<string, OtlpHeaderValue> | undefined;
}
/**
 * Options for {@link layerOtlp}. Configure a base `url` (with
 * `/v1/{signal}` appended per signal), per-signal urls, or a mix — a
 * per-signal entry takes precedence over the base.
 */
export interface OtlpOptions {
    /** Base OTLP/HTTP URL; `/v1/{traces,logs,metrics}` is appended per signal. */
    url?: Input<string> | undefined;
    /** Headers for every signal; per-signal `headers` take precedence. */
    headers?: Record<string, OtlpHeaderValue> | undefined;
    traces?: OtlpSignalOptions | undefined;
    logs?: OtlpSignalOptions | undefined;
    metrics?: OtlpSignalOptions | undefined;
    /**
     * The exported `service.name`.
     * @default the deployed Function/Worker's physical name
     */
    serviceName?: Input<string> | undefined;
}
/**
 * The built-in OTLP exporter as a *binding* layer.
 *
 * At deploy time, building this layer binds the configured urls and
 * headers onto the host Function/Worker (Redacted values as secret
 * bindings) — url and header values accept resource Outputs, so exporter
 * config is wired from resources like any other binding. At runtime the
 * exporter reads the bound values back and ships traces, logs, and metrics
 * over OTLP/HTTP JSON, flushed as each event's scope closes.
 *
 * Exporters COMPOSE: merge several `otlp` layers (or vendor sugar like
 * `Axiom.Telemetry`) and every destination receives the telemetry — spans
 * are serialized once, so trace/span ids agree across destinations:
 *
 * ```ts
 * Effect.provide(
 *   Layer.mergeAll(
 *     Cloudflare.R2.ReadWriteBucketBinding,
 *     Axiom.Telemetry({ token: Ingest, traces: Traces, logs: Logs }),
 *     Alchemy.Telemetry.layerOtlp({
 *       url: "https://api.honeycomb.io",
 *       headers: { "x-honeycomb-team": apiKey },
 *     }),
 *   ),
 * )
 * ```
 */
export declare const layerOtlp: (options: OtlpOptions) => Layer.Layer<never>;
//# sourceMappingURL=Telemetry.d.ts.map