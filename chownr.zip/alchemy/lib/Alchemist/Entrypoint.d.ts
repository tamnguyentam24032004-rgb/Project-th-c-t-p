import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { UserFacingError } from "../UserFacingError.ts";
declare const StackEntrypointError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "StackEntrypointError";
} & Readonly<A>;
export declare class StackEntrypointError extends StackEntrypointError_base<{
    readonly message: string;
}> {
    readonly [UserFacingError] = true;
}
export declare const DEFAULT_ENTRYPOINT = "alchemy.run.ts";
/**
 * The absolute path of the stack entrypoint, or the user-facing error for
 * a missing one. Kept apart from `Session.ts` so the `alchemy dev`
 * supervisor can check the entry before it starts an exec child, without
 * loading the engine that module carries.
 */
export declare const resolveStackEntrypoint: (main: string) => Effect.Effect<string, import("effect/PlatformError").PlatformError | StackEntrypointError, FileSystem.FileSystem | Path.Path>;
export {};
//# sourceMappingURL=Entrypoint.d.ts.map