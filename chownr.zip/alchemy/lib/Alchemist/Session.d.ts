import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Path from "effect/Path";
import { AlchemyContext } from "../AlchemyContext.ts";
import { AuthError, AuthProviders } from "../Auth/AuthProvider.ts";
import * as Stack from "../Stack.ts";
import { Stage } from "../Stage.ts";
import { DEFAULT_ENTRYPOINT, resolveStackEntrypoint, StackEntrypointError } from "./Entrypoint.ts";
export { DEFAULT_ENTRYPOINT, resolveStackEntrypoint, StackEntrypointError };
/** Stage used by routes that inspect a project without addressing a deployment. */
export declare const PLACEHOLDER_STAGE = "placeholder";
/**
 * The default export of an `alchemy.run.ts` entrypoint: the stack effect
 * `Alchemy.Stack(...)` returns, carrying the metadata the factory attaches.
 */
export type StackModule = ReturnType<ReturnType<typeof Stack.make>> & {
    readonly stackName: string;
    readonly providers: Layer.Layer<never> | undefined;
    readonly state: Layer.Layer<never> | undefined;
};
export interface StackModuleLoader {
    readonly import: (url: string) => Promise<{
        readonly default?: unknown;
    }>;
}
export declare const StackModuleLoader: Context.Reference<StackModuleLoader>;
export declare const importStack: (main: string) => Effect.Effect<StackModule, import("effect/PlatformError").PlatformError | StackEntrypointError, FileSystem.FileSystem | Path.Path>;
/**
 * Which project, stage, and credentials a route acts under. Every route that
 * touches the user's program takes one of these; the optional fields fall back
 * to the same defaults the CLI uses.
 */
export interface Target {
    /** Stack entrypoint. @default "alchemy.run.ts" */
    readonly entrypoint?: string;
    /** Stage the run addresses. @default "placeholder" (routes that never deploy) */
    readonly stage?: string;
    /** Profile whose credentials the run uses. Falls back to the active profile. */
    readonly profile?: string;
    /** `.env` file layered under the process environment. */
    readonly envFile?: string;
}
/** A {@link Target} for a route that genuinely acts on one stack instance. */
export interface StackTarget extends Target {
    readonly entrypoint: string;
    readonly stage: string;
}
export interface OpenOptions {
    /** Run local (emulated) providers instead of the real cloud. */
    readonly dev?: boolean;
    /** Adopt pre-existing cloud resources instead of failing on conflict. */
    readonly adopt?: boolean;
    /** Upgrade an out-of-date state store without prompting. */
    readonly updateStateStore?: boolean;
}
export interface CollectAuthProvidersOptions {
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly profile: string;
}
/** Memoize stack sessions and auth registries for one command or API scope. */
export declare const routeCacheLayer: Layer.Layer<never, never, never>;
/**
 * Import the user's stack module and build the services its resources run
 * under. This is the one place that decides what a stack run sees — plan,
 * apply, drift, logs, and state inspection all come through here.
 *
 * The session lives in the surrounding `Scope`; run stack-scoped effects by
 * providing `session.context` (`Effect.provide(effect, session.context)`).
 */
declare const openUncached: (target: Target, options?: OpenOptions | undefined) => Effect.Effect<{
    stack: Stack.CompiledStack<unknown, unknown>;
    /**
     * Everything a stack-scoped effect runs under: the stack's own providers
     * and state store over this session's services.
     */
    context: Context.Context<unknown>;
}, unknown, AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | FileSystem.FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | Path.Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope>;
/** An imported, fully-configured stack instance. */
export type Session = Effect.Success<ReturnType<typeof openUncached>>;
export declare const open: (target: Target, options?: OpenOptions | undefined) => Effect.Effect<{
    stack: Stack.CompiledStack<unknown, unknown>;
    /**
     * Everything a stack-scoped effect runs under: the stack's own providers
     * and state store over this session's services.
     */
    context: Context.Context<unknown>;
}, unknown, AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | FileSystem.FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | Path.Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope>;
export interface BuildStackProvidersOptions {
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly profile?: string;
    readonly registry?: AuthProviders["Service"];
    readonly logger?: Layer.Layer<never, never, never>;
    readonly extra?: Layer.Layer<never, never, never>;
}
export declare const buildStackProviders: (options: BuildStackProvidersOptions) => Effect.Effect<{
    authProviders: {
        [providerName: string]: import("../Auth/AuthProvider.ts").AuthProvider<{
            method: string;
        }, unknown>;
    };
    context: Context.Context<AuthProviders | Stack.Stack | Stage>;
    stackEffect: StackModule;
}, import("effect/PlatformError").PlatformError | StackEntrypointError, AlchemyContext | FileSystem.FileSystem | Path.Path | import("effect/Scope").Scope>;
export declare const collectAuthProviders: (options: CollectAuthProvidersOptions) => Effect.Effect<{
    [providerName: string]: import("../Auth/AuthProvider.ts").AuthProvider<{
        method: string;
    }, unknown>;
}, AuthError | import("effect/PlatformError").PlatformError, AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | FileSystem.FileSystem | import("effect/unstable/http/HttpClient").HttpClient | Path.Path | import("effect/Scope").Scope>;
//# sourceMappingURL=Session.d.ts.map