import * as workers from "@distilled.cloud/cloudflare/workers";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
import { AuthProviders } from "../../Auth/AuthProvider.ts";
import * as CloudflareAccess from "../../Cloudflare/Access.ts";
import * as CloudflareEnvironment from "../../Cloudflare/CloudflareEnvironment.ts";
import * as CloudflareCredentials from "../../Cloudflare/Credentials.ts";
import type { Target } from "../Session.ts";
import type { LogEntry } from "./logs.ts";
export interface StateTarget extends Target {
    /** State-store worker to act on. @default the managed state-store worker */
    readonly workerName?: string;
}
export interface BootstrapInput extends StateTarget {
    readonly force?: boolean;
}
export interface StateLogsInput extends StateTarget {
    readonly limit?: number;
    readonly since?: Date;
}
/**
 * Resolve the profile, Cloudflare account, and provider layer every
 * state-store route (`bootstrap`, `teardown`, logs) is scoped to.
 */
export declare const resolveStateStoreScope: (target: StateTarget) => Effect.Effect<{
    layer: Layer.Layer<CloudflareAccess.Access | AuthProviders | CloudflareEnvironment.CloudflareEnvironment | CloudflareCredentials.Credentials, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore>;
    profile: string;
    accountId: string;
    workerName: string;
}, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore>;
/** Provision (or adopt) the Cloudflare-hosted state-store worker. */
export declare const bootstrap: (input: BootstrapInput) => Effect.Effect<{
    accountId: string;
    workerName: string;
    status: "adopted" | "created" | "redeployed";
    credentialsRefreshed: boolean;
    stateStoreVersion: number;
}, CloudflareAccess.AccessError | import("../../Auth/AuthProvider.ts").AuthError | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("effect/Config").ConfigError | import("@distilled.cloud/fly-io").ConfigError | import("../../Auth/Demand.ts").CredentialsRequired | import("../../Apply.ts").DestroyError | workers.Forbidden | import("effect/unstable/http/HttpClientError").HttpClientError | import("@distilled.cloud/cloudflare/secrets-store").InvalidAccountId | import("../../Output.ts").InvalidReferenceError | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | import("../../Auth/Profile.ts").MissingProviderConfig | import("../../Output.ts").MissingSourceError | import("../../Auth/AuthProvider.ts").NeedsReauth | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError | import("../../State/State.ts").StateStoreError | {
    readonly _tag: "StateStoreVersionNotReady";
    readonly expected: number;
    readonly observed: number | undefined;
    name: string;
    message: string;
    stack?: string;
    cause?: unknown;
    readonly "~effect/Runtime/errorExitCode"?: number;
    readonly "~effect/Runtime/errorReported"?: boolean;
    readonly "~effect/ErrorReporter/ignore"?: boolean;
    readonly "~effect/ErrorReporter/severity"?: import("effect/LogLevel").Severity;
    readonly "~effect/ErrorReporter/attributes"?: import("effect/Record").ReadonlyRecord<string, unknown>;
} | workers.SubdomainNotFound | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError | import("@distilled.cloud/planetscale").DefaultErrors, import("../../AlchemyContext.ts").AlchemyContext | import("../../Artifacts.ts").ArtifactStore | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("../../Interaction.ts").Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore>;
/** Tear down the Cloudflare-hosted state store. */
export declare const teardown: (input: StateTarget) => Effect.Effect<{
    accountId: string;
    workerName: string;
    deleted: string[];
}, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError | workers.QueueConsumerConflict | workers.ServiceBindingConflict | workers.CloudflareOpError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("../../Interaction.ts").Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore>;
/** Query past log entries from the state-store worker, oldest first. */
export declare const stateLogs: (input: StateLogsInput) => Effect.Effect<LogEntry[], import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError | workers.QueryObservabilityTelemetryError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore>;
/** Live-stream log entries from the state-store worker. */
export declare const tailStateLogs: (input: StateTarget) => Stream.Stream<LogEntry, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Profile.ts").MissingProviderConfig | import("effect/PlatformError").PlatformError | import("../../Auth/Profile.ts").ProfileError | workers.CreateScriptTailError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/unstable/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/unstable/http/HttpClient").HttpClient | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/unstable/socket/Socket").WebSocketConstructor>;
//# sourceMappingURL=cloudflare.d.ts.map