import * as Config from "effect/Config";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Nuke from "../../Nuke.ts";
import type { ProviderMode } from "../../ProviderMode.ts";
import { type Target } from "../Session.ts";
export interface ScanInput extends Target {
    readonly mode: ProviderMode;
    /** Provider-id globs to include. Omitted means every provider. */
    readonly include?: ReadonlyArray<string>;
    /** Provider-id globs to exclude. Applied after `include`. */
    readonly exclude?: ReadonlyArray<string>;
    readonly concurrency?: number | "unbounded";
    readonly providerTimeoutSeconds?: number;
}
/** One discovered cloud object, bound to the provider that can delete it. */
export type NukeResource = Nuke.Target;
export interface NukeScan {
    readonly mode: ProviderMode;
    readonly resources: ReadonlyArray<NukeResource>;
    readonly failures: ReadonlyArray<Nuke.ProviderFailure>;
    /** The built provider context {@link execute} deletes under. */
    readonly context: Context.Context<never>;
}
export interface ExecuteInput {
    readonly scan: NukeScan;
    /** The subset of `scan.resources` to delete. */
    readonly resources: ReadonlyArray<NukeResource>;
    readonly strategy: Nuke.Strategy;
    readonly concurrency?: number | "unbounded";
    readonly providerTimeoutSeconds?: number;
}
export type NukeResult = Nuke.Result;
/** Enumerate everything the stack's registered providers can see. */
export declare const scan: (input: ScanInput) => Effect.Effect<{
    mode: ProviderMode;
    resources: readonly Nuke.Target[];
    failures: readonly Nuke.ProviderFailure[];
    context: Context.Context<never>;
}, Config.ConfigError | import("effect/PlatformError").PlatformError | import("../Entrypoint.ts").StackEntrypointError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("effect/Scope").Scope>;
/**
 * Permanently delete the selected resources. Each confirmed deletion is
 * reported through {@link Progress} as `NukeResourceDeleted`.
 */
export declare const execute: (input: ExecuteInput) => Effect.Effect<Nuke.Result, never, never>;
//# sourceMappingURL=nuke.d.ts.map