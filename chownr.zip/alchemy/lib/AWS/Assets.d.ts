import type { Credentials } from "@distilled.cloud/aws/Credentials";
import { Region } from "@distilled.cloud/aws/Region";
import * as s3 from "@distilled.cloud/aws/s3";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import type { HttpClient } from "effect/unstable/http/HttpClient";
import { AWSEnvironment } from "./Environment.ts";
/**
 * Tag key used to identify the alchemy assets bucket.
 */
export declare const ASSETS_BUCKET_TAG = "alchemy::assets-bucket";
/**
 * Error type for Assets service operations.
 */
export type AssetsError = {
    readonly _tag: "AssetsUploadError";
    readonly message: string;
    readonly cause?: unknown;
} | {
    readonly _tag: "AssetsCheckError";
    readonly message: string;
    readonly cause?: unknown;
};
/**
 * Requirements for Assets operations (S3 operations need these).
 */
export type AssetsRequirements = Region | Credentials | HttpClient | AWSEnvironment;
declare const Assets_base: Context.ServiceClass<Assets, "AWS::Assets", {
    /**
     * The name of the assets bucket.
     */
    readonly bucketName: Effect.Effect<string, never, AssetsRequirements>;
    /**
     * Upload an asset to the assets bucket.
     * Uses content-addressed storage: `lambda/{hash}.zip`
     *
     * @param hash - The content hash of the asset
     * @param content - The asset content (zip file)
     * @returns The S3 key where the asset was uploaded
     */
    readonly uploadAsset: (hash: string, content: Uint8Array) => Effect.Effect<string, AssetsError, AssetsRequirements>;
    /**
     * Check if an asset already exists in the assets bucket.
     *
     * @param hash - The content hash to check
     * @returns true if the asset exists
     */
    readonly hasAsset: (hash: string) => Effect.Effect<boolean, AssetsError, AssetsRequirements>;
}>;
export declare class Assets extends Assets_base {
    static BucketName: Effect.Effect<string, never, Assets | AssetsRequirements>;
}
/**
 * Layer that provides the Assets service.
 * Looks up the assets bucket on initialization.
 * If the bucket doesn't exist, the layer will fail - use `assetsLayerWithFallback` for graceful fallback.
 */
export declare const AssetsLive: Layer.Layer<Assets, never, never>;
export declare const lookupAssetsBuckets: Effect.Effect<string[], s3.ListBucketsError, AWSEnvironment | Credentials | HttpClient>;
export declare const lookupAssetsBucket: Effect.Effect<Option.Option<string>, s3.ListBucketsError, AWSEnvironment | Credentials | HttpClient>;
/**
 * Build an account-regional namespace bucket name.
 *
 * Account-regional buckets must follow the naming convention:
 *   `<prefix>-<accountId>-<region>-an`
 *
 * @see https://docs.aws.amazon.com/AmazonS3/latest/userguide/gpbucketnamespaces.html#account-regional-gp-buckets
 */
export declare const createAssetsBucketName: (accountId: string, region: string) => string;
/**
 * Create the tagged assets bucket for the current account+region and wait for
 * it to be addressable. Idempotent — used by `alchemy provider aws bootstrap` and by
 * the transparent local-emulator bootstrap in {@link AssetsLive}.
 */
export declare const createAssetsBucket: Effect.Effect<string, import("@distilled.cloud/aws/Errors").AccessDeniedException | import("@distilled.cloud/aws/Credentials").AwsCredentialProviderError | s3.BucketAlreadyExists | import("@distilled.cloud/aws/Credentials").ConflictingSSORegion | import("@distilled.cloud/aws/Credentials").ConflictingSSOStartUrl | import("@distilled.cloud/aws/SigV4").CryptoError | import("@distilled.cloud/aws/Errors").EndpointError | import("@distilled.cloud/aws/Credentials").ExpiredSSOToken | import("@distilled.cloud/aws/Errors").ExpiredTokenException | import("effect/unstable/http/HttpClientError").HttpClientError | s3.IllegalLocationConstraintException | import("@distilled.cloud/aws/Errors").IncompleteSignature | import("@distilled.cloud/aws/Errors").InternalFailure | s3.InvalidArgument | s3.InvalidBucketName | s3.InvalidLocationConstraint | import("@distilled.cloud/aws/Credentials").InvalidSSOProfile | import("@distilled.cloud/aws/Credentials").InvalidSSOToken | import("@distilled.cloud/aws/SigV4").InvalidSigningHeaders | import("@distilled.cloud/aws/SigV4").InvalidSigningUrl | import("@distilled.cloud/aws/Errors").MalformedHttpRequestException | import("@distilled.cloud/aws/Credentials").MissingRegion | import("@distilled.cloud/aws/Errors").NoMatchingRuleError | s3.NoSuchBucket | import("@distilled.cloud/aws/Errors").NotAuthorized | s3.NotFound | import("@distilled.cloud/aws/Errors").OperationAborted | import("@distilled.cloud/aws/Errors").OptInRequired | s3.ParseError | import("effect/PlatformError").PlatformError | import("@distilled.cloud/aws/Credentials").ProfileNotFound | import("@distilled.cloud/aws/Errors").RequestAbortedException | import("@distilled.cloud/aws/Errors").RequestEntityTooLargeException | import("@distilled.cloud/aws/Errors").RequestExpired | s3.RequestLimitExceeded | import("@distilled.cloud/aws/Errors").RequestTimeoutException | import("@distilled.cloud/aws/Errors").ServiceUnavailable | s3.SlowDown | import("@distilled.cloud/aws/Credentials").SsoPortalError | import("@distilled.cloud/aws/Errors").ThrottlingException | import("@distilled.cloud/aws/Errors").UnknownAwsError | import("@distilled.cloud/aws/Errors").UnknownOperationException | import("@distilled.cloud/aws/Errors").UnrecognizedClientException | import("@distilled.cloud/aws/Errors").ValidationError | import("@distilled.cloud/aws/Errors").ValidationException, AWSEnvironment | Credentials | HttpClient>;
export declare const ensureAssetsBucketTags: (bucketName: string) => Effect.Effect<void, s3.PutBucketTaggingError, Credentials | HttpClient>;
export {};
//# sourceMappingURL=Assets.d.ts.map