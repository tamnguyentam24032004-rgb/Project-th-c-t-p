import type * as aa from "@distilled.cloud/aws/accessanalyzer";
import type * as Effect from "effect/Effect";
import * as Binding from "../../Binding.ts";
/**
 * Runtime binding for `access-analyzer:CancelPolicyGeneration`.
 *
 * Cancels an in-progress policy-generation job. Provide the implementation
 * with `Effect.provide(AWS.AccessAnalyzer.CancelPolicyGenerationHttp)`.
 * ### Policy Generation
 * **Example:** Cancel a Generation Job
 * ```typescript
 * const cancelGeneration =
 *   yield* AWS.AccessAnalyzer.CancelPolicyGeneration();
 * yield* cancelGeneration({ jobId });
 * ```
 *
 * @binding
 */
export interface CancelPolicyGeneration extends Binding.Service<CancelPolicyGeneration, "AWS.AccessAnalyzer.CancelPolicyGeneration", () => Effect.Effect<(request: aa.CancelPolicyGenerationRequest) => Effect.Effect<aa.CancelPolicyGenerationResponse, aa.CancelPolicyGenerationError>>> {
}
export declare const CancelPolicyGeneration: CancelPolicyGeneration;
//# sourceMappingURL=CancelPolicyGeneration.d.ts.map