import * as Context from "effect/Context";
import type { Stack, StackSpec } from "./Stack.ts";
export declare const StackContext: Context.ServiceClass<Stack, "Stack", Omit<StackSpec<any>, "output">>;
//# sourceMappingURL=StackContext.d.ts.map