export class Cursor {
}
