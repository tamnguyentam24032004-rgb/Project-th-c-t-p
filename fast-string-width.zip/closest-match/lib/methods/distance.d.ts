export declare const distance: (a: string, b: string) => number;
