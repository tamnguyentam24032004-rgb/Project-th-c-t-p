export declare const closestMatch: (target: string, array: string[], showOccurrences?: boolean) => string | string[] | null;
